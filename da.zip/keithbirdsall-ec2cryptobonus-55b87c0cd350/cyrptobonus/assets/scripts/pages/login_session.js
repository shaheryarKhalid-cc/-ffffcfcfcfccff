//load the document build the page
// function login_session(form)/*function to check userid & password*/
// {
//     /*the following code checkes whether the entered userid and password are matching*/
//     let username = form.userid.value;
//     let password = form.pswrd.value;

//     if(form.userid.value == "pilot" && form.pswrd.value == "pilot@123")
//     {
//         sessionStorage.setItem("username", username);
//         sessionStorage.setItem("password", password);
//         window.location.href = "index.html";
//     }
//     else
//     {
//         alert("Error Password or Username")/*displays error message*/
//     }
// }